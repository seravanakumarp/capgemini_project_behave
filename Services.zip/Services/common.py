def FindElem(driver, by, value):
    try:
        return driver.find_element(by, value)
    except Exception as e:
        print(f"[ERROR] Element not found: {value} — {e}")
        return False

def FindElems(driver, by, value):
    try:
        return driver.find_elements(by, value)
    except Exception as e:
        print(f"[ERROR] Elements not found: {value} — {e}")
        return []
