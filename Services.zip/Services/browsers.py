from selenium import webdriver
from selenium.webdriver.chrome.options import Options

class BROWSER:
    def __init__(self, browser="chrome", headless=False):
        if browser == "chrome":
            options = Options()
            if headless:
                options.add_argument("--headless")
            options.add_argument("--start-maximized")
            self.driver = webdriver.Chrome(options=options)
        else:
            raise ValueError(f"Unsupported browser: {browser}")
