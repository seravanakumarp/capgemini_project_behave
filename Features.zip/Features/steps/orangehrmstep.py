from behave import *
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service

@given(u'launch chrome browser')
def launchBrowser(context):
    service = Service("C:/Users/sekumarp/Downloads/chromedriver-win64/chromedriver.exe")
    context.driver = webdriver.Chrome(service=service)
# context is an object passed to every step function.
# It acts as a container for storing data that needs to be shared between steps.
# You can dynamically add attributes to it, like context.user, context.response, or context.base.
@when(u'open toolsqa homepage')
def openHomePage(context):
    context.driver.get("https://www.toolsqa.com/selenium-training/")

@then(u'verify that the logo present on page')
def verifyLogo(context):
    logo = context.driver.find_element(By.XPATH, "/html/body/header/nav/div/div/a/img")

    assert logo.is_displayed(), "Logo is not displayed on the page"

@then(u'close browser')
def closeBrowser(context):
    context.driver.quit()

# assertions are used to verify that the expected
# behavior described in a scenario actually occurs during test execution.
# Assertion Type	                    Example
# Equality	                            assert x == y
# Inequality	                        assert x != y
# Membership	                        assert item in collection
# Boolean	                            assert condition
# Exception Handling	                Use try/except or pytest.raises


