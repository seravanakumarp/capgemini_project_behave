from behave import given, when, then
from Services.browsers import *
from Services.common import *
from POM.base_pom import Base
from POM.home_page_pom import Homepage
import time
@given('User loads www.google.com in browser')
def step_impl(context):
    context.base = Base(browser="chrome", headless=False, baseURL="https://www.google.com")
    context.base.do_open_page()

@when('User input search term in search box and submit it')
def step_impl(context):
    context.search_term = "Behave"  # You can make this dynamic later
    context.base.do_perform_search(context.search_term)


@then('User navigates to Web result page of searched term')
def step_impl(context):
    time.sleep(2)  # Wait for page to load
    title = context.base.get_page_title()
    print("Page title is:", title)
    assert context.search_term.lower() in title.lower(), f"Expected '{context.search_term}' in page title, got '{title}'"
   #checks if a specified search term is present in a web page's title.
    # If the search term is not found, the test fails and produces a descriptive error message.
    time.sleep(4)

@then('page title contains search term')
def step_impl(context):
    title = context.base.get_page_title()
    assert context.search_term.lower() in title.lower(), f"Search term '{context.search_term}' not found in page title '{title}'"
    time.sleep(4)