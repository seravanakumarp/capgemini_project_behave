from behave import *
from selenium import webdriver
from selenium.common import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

@given(u'I launch Chrome browser')
def step_impl(context):
    context.driver=webdriver.Chrome()

@when(u'I open orange HRM Homepage')
def step_impl(context):
    context.driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login")

@when(u'Enter username "{user}" and password "{pwd}"')
def step_impl(context,user,pwd):
        # Wait for the username input to be visible
        username_xpath = "//div[contains(@class, 'oxd-form-row')]//input[@placeholder='Username']"
        WebDriverWait(context.driver, 10).until(EC.visibility_of_element_located((By.XPATH, username_xpath)))
        username_input = context.driver.find_element(By.XPATH, username_xpath)
        username_input.send_keys(user)

        # Wait for the password input to be visible
        password_xpath = "//div[contains(@class, 'oxd-form-row')]//input[@placeholder='Password']"
        WebDriverWait(context.driver, 10).until(EC.visibility_of_element_located((By.XPATH, password_xpath)))
        password_input = context.driver.find_element(By.XPATH, password_xpath)
        password_input.send_keys(pwd)

@when(u'Click on login button')
def step_impl(context):
        # Wait for the login button to be clickable
        login_button_xpath = "//button[@type='submit']"
        WebDriverWait(context.driver, 10).until(EC.element_to_be_clickable((By.XPATH, login_button_xpath)))
        login_button = context.driver.find_element(By.XPATH, login_button_xpath)
        login_button.click()


@then(u'User must successfully login to the Dashboard Page')
def step_impl(context):
    # Wait for the Dashboard element to be visible
    dashboard_xpath = "//span[text()='Dashboard']"  # Example XPath
    try:
        WebDriverWait(context.driver, 20).until(EC.visibility_of_element_located((By.XPATH, dashboard_xpath)))
        print("Successfully logged in and reached the Dashboard!")
    except Exception as e:
        print(f"Error: {e}")
        print("Page source:\n", context.driver.page_source)  # Print page source for debugging
