from behave import given, when, then
from selenium import webdriver
from POM.search_page import GooglePage
from POM.wikipedia_search import WikipediaPage
import time

@given('the user is on the Google homepage')
def step_impl(context):
    context.driver = webdriver.Chrome()
    context.google_page = GooglePage(context.driver)
    context.google_page.load()

@when('the user searches for "{query}"')
def step_impl(context, query):
    context.google_page.search(query)

@then('the search results should contain "{expected_text}"')
def step_impl(context, expected_text):
    time.sleep(2)  # Let the results load
    assert expected_text in context.driver.page_source
    context.driver.quit()


@when('clicks the Wikipedia link')
def step_impl(context):
    time.sleep(2)
    links = context.driver.find_elements("partial link text", "Wikipedia")
    assert links, "Wikipedia link not found"
    links[0].click()
    context.wikipedia_page = WikipediaPage(context.driver)

@then('the Wikipedia page title should be "{expected_title}"')
def step_impl(context, expected_title):
    actual_title = context.wikipedia_page.get_title()
    assert actual_title == expected_title, f"Expected '{expected_title}', got '{actual_title}'"
    context.driver.quit()
