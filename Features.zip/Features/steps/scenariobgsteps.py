from behave import given, when, then
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.alert import Alert
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException

@given('the browser is opened')
def step_open_browser(context):
    context.driver = webdriver.Chrome()
    context.driver.maximize_window()

@when('I provide valid credentials "{username}" and "{password}"')
def step_enter_credentials(context, username, password):
    context.driver.get("https://demo.guru99.com/V4/")
    context.driver.find_element(By.NAME, "uid").clear()
    context.driver.find_element(By.NAME, "uid").send_keys(username)
    context.driver.find_element(By.NAME, "password").clear()
    context.driver.find_element(By.NAME, "password").send_keys(password)
    context.driver.find_element(By.NAME, "btnLogin").click()

@then('the title of the page should be "{expected_title}"')
def step_verify_title(context, expected_title):
    try:
        WebDriverWait(context.driver, 3).until(EC.alert_is_present())
        alert = Alert(context.driver)
        alert_text = alert.text
        print(f"Alert detected: {alert_text}")
        alert.accept()
        assert False, f"Login failed with alert: {alert_text}"
    except TimeoutException:
        pass  # No alert

    actual_title = context.driver.title.strip()
    assert actual_title == expected_title, f"Expected title '{expected_title}', but got '{actual_title}'"
    context.driver.quit()

@then('I should see a success message')
def step_verify_success(context):
    try:
        WebDriverWait(context.driver, 3).until(EC.alert_is_present())
        alert = Alert(context.driver)
        alert_text = alert.text
        print(f"Alert detected: {alert_text}")
        alert.accept()
        assert False, f"Login failed with alert: {alert_text}"
    except TimeoutException:
        pass  # No alert

    try:
        manager_id = WebDriverWait(context.driver, 5).until(
            EC.presence_of_element_located((By.XPATH, "//td[contains(text(),'Manager Id')]"))
        )
        assert manager_id.is_displayed(), "Manager ID not displayed"
        print("Login successful: Manager ID is displayed.")
    except Exception as e:
        assert False, f"Login failed or Manager ID not found: {str(e)}"
    finally:
        context.driver.quit()

@when('I login with the following credentials')
def step_login_with_table(context):
    context.results = []
    for row in context.table:
        username = row['username']
        password = row['password']
        context.driver.get("https://demo.guru99.com/V4/")
        context.driver.find_element(By.NAME, "uid").clear()
        context.driver.find_element(By.NAME, "uid").send_keys(username)
        context.driver.find_element(By.NAME, "password").clear()
        context.driver.find_element(By.NAME, "password").send_keys(password)
        context.driver.find_element(By.NAME, "btnLogin").click()

        # Handle alert
        try:
            WebDriverWait(context.driver, 3).until(EC.alert_is_present())
            alert = Alert(context.driver)
            alert_text = alert.text
            alert.accept()
            context.results.append((username, f"Failed - Alert: {alert_text}"))
            continue
        except TimeoutException:
            pass  # No alert

        # Check for Manager ID
        try:
            manager_id = WebDriverWait(context.driver, 5).until(
                EC.presence_of_element_located((By.XPATH, "//td[contains(text(),'Manager Id')]"))
            )
            if manager_id.is_displayed():
                context.results.append((username, "Success"))
            else:
                context.results.append((username, "Failed - Manager ID not displayed"))
        except Exception as e:
            context.results.append((username, f"Failed - Exception: {str(e)}"))

@then('I should see the login result for each credential')
def step_verify_results(context):
    for username, result in context.results:
        print(f"Login attempt for '{username}': {result}")
    context.driver.quit()
