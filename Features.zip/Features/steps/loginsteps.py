from behave import given, when, then
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.alert import Alert
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException

@given('I launch Chrome Browser')
def step_launch_browser(context):
    context.driver = webdriver.Chrome()
    context.driver.maximize_window()

@when('I open Test automation homepage')
def step_open_homepage(context):
    context.driver.get("https://demo.guru99.com/V4/")  # Replace with actual homepage URL if different

@when('Enter valid username and password')
def step_enter_credentials(context):
    context.driver.find_element(By.NAME, "uid").clear()
    context.driver.find_element(By.NAME, "uid").send_keys("mngr640223")  # Replace with actual valid username
    context.driver.find_element(By.NAME, "password").clear()
    context.driver.find_element(By.NAME, "password").send_keys("dUvUbeb")  # Replace with actual valid password

@when('click on login button')
def step_click_login(context):
    context.driver.find_element(By.NAME, "btnLogin").click()

@then('User must login to the Dashboard page')
def step_verify_dashboard(context):
    try:
        WebDriverWait(context.driver, 3).until(EC.alert_is_present())
        alert = Alert(context.driver)
        alert_text = alert.text
        alert.accept()
        assert False, f"Login failed with alert: {alert_text}"
    except TimeoutException:
        pass  # No alert

    try:
        dashboard_title = context.driver.title
        assert "Guru99 Bank" in dashboard_title, f"Unexpected title: {dashboard_title}"
        print("Login successful. Dashboard loaded.")
    finally:
        context.driver.quit()

@when('navigate to search page')
def step_navigate_search(context):
    try:
        WebDriverWait(context.driver, 10).until(
            EC.element_to_be_clickable((By.LINK_TEXT, "Search"))
        ).click()
    except TimeoutException:
        assert False, "Search link not found or not clickable"

@then('search page should display')
def step_verify_search_page(context):
    try:
        page_title = context.driver.title
        assert "Search" in page_title, f"Search page not displayed. Title was: {page_title}"
    except Exception as e:
        assert False, f"Search page verification failed: {str(e)}"

@when('navigate to advanced search page')
def step_navigate_advanced_search(context):
    try:
        WebDriverWait(context.driver, 10).until(
            EC.element_to_be_clickable((By.PARTIAL_LINK_TEXT, "Advanced"))
        ).click()
    except TimeoutException:
        assert False, "Advanced Search link not found or not clickable"

@then('advanced search page should display')
def step_verify_advanced_search_page(context):
    try:
        page_title = context.driver.title
        assert "Advanced Search" in page_title, f"Advanced Search page not displayed. Title was: {page_title}"
    except Exception as e:
        assert False, f"Advanced Search page verification failed: {str(e)}"
