from POM.base_pom import Base
from POM.home_page_pom import Homepage

# def before_scenario(context, scenario):
#     context.base = Base(browser="chrome", headless=False, baseURL="https://www.google.com")
#     context.Home = Homepage(context.base)
#
# def after_scenario(context, scenario):
#     context.base.Teardown()
#
def after_scenario(context, scenario):
    if hasattr(context, 'driver'):
        context.driver.quit()

