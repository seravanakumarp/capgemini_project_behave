from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class WikipediaPage:
    def __init__(self, driver):
        self.driver = driver
        self.wait = WebDriverWait(driver, 10)

    def get_title(self):
        self.wait.until(lambda d: d.title != "")
        # This is an anonymous function(lambda ) that takes the driver d and checks if the page title is not empty.
        return self.driver.title
